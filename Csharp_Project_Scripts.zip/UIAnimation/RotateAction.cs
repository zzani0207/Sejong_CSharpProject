using UnityEngine;
using PrimeTween;
using Sirenix.OdinInspector;
using System;

/// <summary>
/// UI 요소의 회전(localEulerAngles)을 애니메이션합니다.
/// useRelative=true일 때 endRotation은 변화량(덧셈)으로 적용됩니다.
/// </summary>
[Serializable]
public class RotateAction : UIAnimAction
{
    public enum RotateMode { Current, Specific }

    [BoxGroup("Rotation 설정")]
    [LabelText("시작 방식"),EnumToggleButtons] public RotateMode startMode = RotateMode.Current;

    [BoxGroup("Rotation 설정"), ShowIf("startMode", RotateMode.Specific)]
    public Vector3 startRotation = Vector3.zero;

    [BoxGroup("Rotation 설정")]
    [LabelText("종료 방식"), EnumToggleButtons] public RotateMode endMode = RotateMode.Specific;

    [BoxGroup("Rotation 설정"), ShowIf("endMode", RotateMode.Specific)]
    public Vector3 endRotation = new Vector3(0, 0, 360f); // 기본값으로 한 바퀴 설정

    private Quaternion snapshotRotation;

protected override Tween InvokeTween(RectTransform target, bool useUnscaledTime)
    {
        // 시작 오일러 각도 설정
        Vector3 fromEuler = (startMode == RotateMode.Current) ? target.localEulerAngles : startRotation;
        target.localEulerAngles = fromEuler;
        Quaternion fromQuat = target.localRotation;

        Quaternion toQuat;
        if (useRelative)
        {
            // Quaternion 곱셈으로 상대 회전 계산 → 오일러 wrap-around 문제 해결
            toQuat = fromQuat * Quaternion.Euler(endRotation);
        }
        else
        {
            Vector3 toEuler = (endMode == RotateMode.Current) ? target.localEulerAngles : endRotation;
            toQuat = Quaternion.Euler(toEuler);
        }

        return Tween.LocalRotation(
            target: target,
            endValue: toQuat,
            duration: duration,
            ease: useCustomCurve ? customCurve : ease,
            cycles: cycles,
            cycleMode: cycleMode,
            startDelay: startDelay,
            useUnscaledTime: useUnscaledTime
        );
    }

    public override void RecordState(RectTransform masterTarget)
    {
        var t = GetTarget(masterTarget);
        if (t == null)
        {
            snapshotRotation = Quaternion.identity;
            return;
        }
        snapshotRotation = t.localRotation;
    }

    public override void ResetState(RectTransform masterTarget)
    {
        var t = GetTarget(masterTarget);
        if (t != null) t.localRotation = snapshotRotation;
    }
}