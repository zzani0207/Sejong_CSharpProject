using UnityEngine;
using PrimeTween;
using Sirenix.OdinInspector;
using System;

/// <summary>
/// UI 요소의 위치(anchoredPosition)를 애니메이션합니다.
/// useRelative=true일 때 endPos는 변화량(덧셈)으로 적용됩니다.
/// </summary>
[Serializable]
public class MoveAction : UIAnimAction
{
    public enum PositionMode { Current, Specific }

    [BoxGroup("Position 설정")]
    [LabelText("시작 방식"), EnumToggleButtons] public PositionMode startMode = PositionMode.Current;
    
    [BoxGroup("Position 설정"), ShowIf("startMode", PositionMode.Specific)]
    public Vector2 startPos;

    [BoxGroup("Position 설정")]
    [LabelText("종료 방식"), EnumToggleButtons] public PositionMode endMode = PositionMode.Specific;
    
    [BoxGroup("Position 설정"), ShowIf("endMode", PositionMode.Specific)]
    public Vector2 endPos;

    private Vector2 snapshotPos;

    protected override Tween InvokeTween(RectTransform target, bool useUnscaledTime)
    {
        Vector2 targetPos = target.anchoredPosition;
        Vector2 from;
        Vector2 to;

        if (useRelative)
        {
            from = (startMode == PositionMode.Current) ? targetPos : targetPos + startPos;
            to = from + endPos;
        }
        else
        {
            from = (startMode == PositionMode.Current) ? targetPos : startPos;
            to = (endMode == PositionMode.Current) ? targetPos : endPos;
        }

        target.anchoredPosition = from;

        return Tween.UIAnchoredPosition(target, 
            endValue: to, 
            duration: duration, 
            ease: useCustomCurve ? customCurve : ease, 
            cycles: cycles, 
            cycleMode: cycleMode, 
            startDelay: startDelay, 
            useUnscaledTime: useUnscaledTime);
    }

    public override void RecordState(RectTransform masterTarget)
    {
        RectTransform t = GetTarget(masterTarget);
        if (t == null)
        {
            snapshotPos = Vector2.zero;
            return;
        }
        snapshotPos = t.anchoredPosition;
    }

    public override void ResetState(RectTransform masterTarget)
    {
        RectTransform t = GetTarget(masterTarget);
        if (t != null) t.anchoredPosition = snapshotPos;
    }
}