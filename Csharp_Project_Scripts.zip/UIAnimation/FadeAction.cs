using UnityEngine;
using PrimeTween;
using Sirenix.OdinInspector;
using System;

/// <summary>
/// UI 요소의 투명도를 애니메이션합니다.
/// 대상 오브젝트에 CanvasGroup 컴포넌트가 필수입니다.
/// useRelative=true일 때 endAlpha는 변화량(덧셈)으로 적용됩니다.
/// </summary>
[Serializable]
public class FadeAction : UIAnimAction
{
    public enum AlphaMode { Current, Specific }

    [BoxGroup("Fade 설정")]
    [LabelText("시작 방식"), EnumToggleButtons] public AlphaMode startMode = AlphaMode.Current;
    
    [BoxGroup("Fade 설정"), ShowIf("startMode", AlphaMode.Specific)]
    [Range(0f, 1f)] public float startAlpha = 0f;

    [BoxGroup("Fade 설정"), HideIf("useRelative")]
    [LabelText("종료 방식"), EnumToggleButtons] public AlphaMode endMode = AlphaMode.Specific;
    
    [BoxGroup("Fade 설정"), ShowIf("ShowFadeEndAlpha")]
    [LabelText("$FadeEndLabel")]
    [PropertyRange("FadeEndMin", 1f)]
    public float endAlpha = 1f;

    private float snapshotAlpha;

    protected override Tween InvokeTween(RectTransform target, bool useUnscaledTime)
    {
        var cg = GetCanvasGroup(target);
        if (cg == null) return default;

        float from = (startMode == AlphaMode.Current) ? cg.alpha : startAlpha;
        float to;

        if (useRelative)
        {
            // 상대값: endAlpha는 변화량 (덧셈)
            to = Mathf.Clamp01(from + endAlpha);
        }
        else
        {
            // 절대값: endAlpha는 목표 투명도
            to = (endMode == AlphaMode.Current) ? cg.alpha : endAlpha;
        }

        cg.alpha = from;

        return Tween.Alpha(
            target: cg,
            endValue: to,
            duration: duration,
            ease: useCustomCurve ? customCurve : ease,
            cycles: cycles,
            cycleMode: cycleMode,
            startDelay: startDelay,
            useUnscaledTime: useUnscaledTime
        );
    }

    public override void RecordState(RectTransform masterTarget)
    {
        var t = GetTarget(masterTarget);
        if (t == null)
        {
            snapshotAlpha = 1f;
            return;
        }

        var cg = GetCanvasGroup(t);
        snapshotAlpha = (cg != null) ? cg.alpha : 1f;
    }

    public override void ResetState(RectTransform masterTarget)
    {
        var t = GetTarget(masterTarget);
        if (t != null)
        {
            var cg = t.GetComponent<CanvasGroup>();
            if (cg != null) cg.alpha = snapshotAlpha;
        }
    }

    /// <summary>
    /// 대상 오브젝트의 CanvasGroup을 반환합니다.
    /// CanvasGroup이 없으면 null을 반환하고 경고 메시지를 출력합니다.
    /// </summary>
    private CanvasGroup GetCanvasGroup(RectTransform target)
    {
        var cg = target.GetComponent<CanvasGroup>();
        if (cg == null)
        {
            Debug.LogWarning($"[FadeAction] {target.gameObject.name}에 CanvasGroup 컴포넌트가 없습니다. " +
                $"이 오브젝트에 FadeAction이 작동하지 않습니다. CanvasGroup 컴포넌트를 추가해주세요.");
        }
        return cg;
    }


private bool ShowFadeEndAlpha => useRelative || endMode == AlphaMode.Specific;
    private string FadeEndLabel => useRelative ? "변화량 (-1~1)" : "목표 알파";
    private float FadeEndMin => useRelative ? -1f : 0f;
}