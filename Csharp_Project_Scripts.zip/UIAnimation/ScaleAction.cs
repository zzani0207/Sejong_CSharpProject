using UnityEngine;
using PrimeTween;
using Sirenix.OdinInspector;
using System;

/// <summary>
/// UI 요소의 크기(scale)를 애니메이션합니다.
/// useRelative=true일 때 endScale은 배율(곱셈)로 적용됩니다.
/// </summary>
[Serializable]
public class ScaleAction : UIAnimAction
{
    public enum ScaleMode { Current, Specific }

    [BoxGroup("Scale 설정")]
    [LabelText("시작 방식"), EnumToggleButtons] public ScaleMode startMode = ScaleMode.Current;
    
    [BoxGroup("Scale 설정"), ShowIf("startMode", ScaleMode.Specific)]
    public Vector3 startScale = Vector3.zero;

    [BoxGroup("Scale 설정")]
    [LabelText("종료 방식"), EnumToggleButtons] public ScaleMode endMode = ScaleMode.Specific;
    
    [BoxGroup("Scale 설정"), ShowIf("endMode", ScaleMode.Specific)]
    public Vector3 endScale = Vector3.one;

    private Vector3 snapshotScale;

    protected override Tween InvokeTween(RectTransform target, bool useUnscaledTime)
    {
        Vector3 from = (startMode == ScaleMode.Current) ? target.localScale : startScale;
        Vector3 to;

        if (useRelative)
        {
            to = new Vector3(from.x * endScale.x, from.y * endScale.y, from.z * endScale.z);
        }
        else
        {
            to = (endMode == ScaleMode.Current) ? target.localScale : endScale;
        }

        target.localScale = from;

        return Tween.Scale(
            target: target,
            endValue: to,
            duration: duration,
            ease: useCustomCurve ? customCurve : ease,
            cycles: cycles,
            cycleMode: cycleMode,
            startDelay: startDelay,
            useUnscaledTime: useUnscaledTime
        );
    }

    public override void RecordState(RectTransform masterTarget)
    {
        var t = GetTarget(masterTarget);
        if (t == null)
        {
            snapshotScale = Vector3.one;
            return;
        }
        snapshotScale = t.localScale;
    }

    public override void ResetState(RectTransform masterTarget)
    {
        var t = GetTarget(masterTarget);
        if (t != null) t.localScale = snapshotScale;
    }
}