using UnityEngine;
using UnityEngine.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using PrimeTween;
using Sirenix.OdinInspector;

[ExecuteAlways]
[RequireComponent(typeof(RectTransform))]
public class UIAnimationMaster : MonoBehaviour
{
    public enum PlaybackPolicy { Restart, Ignore }
    public enum UIState { Closed, Opening, Opened, Closing }
    public enum OutPlaybackTiming { Manual, AfterInComplete }

    #region [ Settings & Policy ]
    [TabGroup("Settings")]
    [EnumToggleButtons, Tooltip("이미 재생 중일 때 새로운 요청이 오면 어떻게 할지")]
    public PlaybackPolicy policy = PlaybackPolicy.Restart;

    [TabGroup("Settings")]
    [Tooltip("활성화될 때 자동으로 In 애니메이션을 재생할지")]
    public bool playOnEnable = true;
    
    [TabGroup("Settings")]
    [EnumToggleButtons, Tooltip("Out 애니메이션 실행 시점\n• Manual: 외부에서 PlayOut() 직접 호출 (원하는 시점에 자유롭게)\n• AfterInComplete: In 완료 후 즉시 자동 실행 (토스트/알림 UI용)")]
    public OutPlaybackTiming outPlaybackTiming = OutPlaybackTiming.Manual;

    [TabGroup("Settings")]
    [Tooltip("Out 애니메이션이 완료되면 게임 오브젝트를 비활성화할지")]
    public bool deactivateOnOutComplete = true;

    [TabGroup("Settings")]
    [Tooltip("애니메이션이 일시정지 상태에서도 계속 재생할지")]
    public bool useUnscaledTime = true;

    [TabGroup("Settings")]
    [Tooltip("애니메이션 도중 클릭을 방지할지 (CanvasGroup 필요)")]
    public bool blockInteraction = true;
    #endregion

    #region [ Animation Actions ]
    [TabGroup("In Actions")]
    [InfoBox("$InDurationText", InfoMessageType.Info)]
    [SerializeReference, TypeFilter(nameof(GetActionTypes))]
    [ListDrawerSettings(HideAddButton = false, 
        DraggableItems = true, 
        ShowFoldout = true,
        NumberOfItemsPerPage = 5,
        ShowIndexLabels = false
        )
    ]

    public List<UIAnimAction> inActions = new List<UIAnimAction>();

    [TabGroup("Loop Actions")]
    [InfoBox("In 애니메이션 재생 후 무한 반복")]
    [SerializeReference, TypeFilter(nameof(GetActionTypes))]
    [ListDrawerSettings(ShowFoldout = true)]
    public List<UIAnimAction> loopActions = new List<UIAnimAction>();

    [TabGroup("Out Actions")]
    [InfoBox("$OutDurationText", InfoMessageType.Info)]
    [SerializeReference, TypeFilter(nameof(GetActionTypes))]
    [ListDrawerSettings(ShowFoldout = true)]
    public List<UIAnimAction> outActions = new List<UIAnimAction>();
    #endregion

    #region [ Events ]
    [TabGroup("Events")]
    public UnityEvent onInStart, onInComplete;
    [TabGroup("Events")]
    public UnityEvent onOutStart, onOutComplete;
    #endregion

    #region [ Internal State ]
    private RectTransform rectTransform;
    private Sequence activeSequence;
    private List<Tween> activeLoopTweens = new List<Tween>();
    private CanvasGroup canvasGroup;
    private bool isPreviewing;

    [SerializeField, ReadOnly] 
    private UIState currentState = UIState.Closed;
    #endregion

    private void Awake()
    {
        rectTransform = GetComponent<RectTransform>();
        canvasGroup = GetComponent<CanvasGroup>();
    }
    private void OnEnable()
    {
        if (Application.isPlaying)
        {
            if(currentState == UIState.Closing) currentState = UIState.Closed;        
            if (playOnEnable) PlayIn();
        }
    }
    private void OnDestroy() => Cleanup();
private void OnDisable()
    {
        Cleanup();
    }

    private void Cleanup()
    {
        if (activeSequence.isAlive) activeSequence.Stop();
        StopLoopActions();
    }

    #region [ Public Play Methods ]
public void PlayIn(Action onCompleteCallback = null, bool isPreview = false)
    {
        if(inActions == null || inActions.Count == 0)
        {
            currentState = UIState.Opened;
            if (!WillAutoPlayOut(isPreview)) StartLoopActions();
            onInComplete?.Invoke();
            onCompleteCallback?.Invoke();
            TriggerAutoPlayOut(isPreview);
            return;
        }

        if(currentState == UIState.Opened || currentState == UIState.Opening)
        {
            if (policy == PlaybackPolicy.Ignore) return;
        }

        if (!HandlePolicy()) return;

        currentState = UIState.Opening;
        SetInteractable(false);

        if (!isPreview) onInStart?.Invoke();
        
        PlaySequence(inActions, () =>
        {
            currentState = UIState.Opened;
            SetInteractable(true);
            if (!WillAutoPlayOut(isPreview)) StartLoopActions();
            if (!isPreview) onInComplete?.Invoke();
            onCompleteCallback?.Invoke();
            TriggerAutoPlayOut(isPreview);
        });
    }

    /// <summary>
    /// OutPlaybackTiming에 따라 자동으로 PlayOut을 호출합니다.
    /// AfterInComplete 옵션일 때 In 애니메이션 완료 후 자동으로 실행됩니다.
    /// </summary>
    private void TriggerAutoPlayOut(bool isPreview)
    {
        if (isPreview) return; // 프리뷰 모드에서는 자동 실행 안 함
        
        if (Application.isPlaying && outPlaybackTiming == OutPlaybackTiming.AfterInComplete)
        {
            PlayOut();
        }
    }

/// <summary>
    /// In 완료 후 Out이 자동 실행될 예정인지 확인합니다.
    /// 루프 애니메이션 시작 여부를 결정하는 데 사용됩니다.
    /// </summary>
    private bool WillAutoPlayOut(bool isPreview)
    {
        return !isPreview && Application.isPlaying && outPlaybackTiming == OutPlaybackTiming.AfterInComplete;
    }


    [TabGroup("Out Actions")]
    public void PlayOut(Action onCompleteCallback = null, bool isPreview = false)
    {
        StopLoopActions();

        if(outActions == null || outActions.Count == 0)
        {
            CompleteOutAnimation(onCompleteCallback, isPreview);
            return;
        }

        if(currentState == UIState.Closed || currentState == UIState.Closing)
        {
            if (policy == PlaybackPolicy.Ignore) return;
        }

        if (!HandlePolicy()) return;

        currentState = UIState.Closing;
        SetInteractable(false);

        if (!isPreview) onOutStart?.Invoke();

        PlaySequence(outActions, () =>
        {
            CompleteOutAnimation(onCompleteCallback, isPreview);
        });
    }

    /// <summary>
    /// Out 애니메이션 완료 처리를 담당합니다.
    /// 상태 변경, 콜백 호출, 오브젝트 비활성화를 수행합니다.
    /// </summary>
    private void CompleteOutAnimation(Action onCompleteCallback, bool isPreview)
    {
        currentState = UIState.Closed;
        SetInteractable(true);

        if (!isPreview) onOutComplete?.Invoke();
        onCompleteCallback?.Invoke();
        
        if (Application.isPlaying && deactivateOnOutComplete)
            gameObject.SetActive(false);
    }
    #endregion

    #region [ Loop Actions ]
    /// <summary>
    /// In 애니메이션 완료 후 무한 반복되는 애니메이션을 시작합니다.
    /// </summary>
    private void StartLoopActions()
    {
        StopLoopActions();

        if (loopActions == null || loopActions.Count == 0) return;

        foreach (var anim in loopActions)
        {
            var t = anim.GenerateTween(rectTransform, useUnscaledTime);
            if(t.isAlive) activeLoopTweens.Add(t);
        }
    }

    /// <summary>
    /// 루프 애니메이션을 모두 중지합니다.
    /// </summary>
    private void StopLoopActions()
    {
        foreach (var t in activeLoopTweens)
        {
            if (t.isAlive) t.Stop();
        }
        activeLoopTweens.Clear();
    }
    #endregion

    #region [ Core Logic ]
    /// <summary>
    /// 주어진 액션들을 시퀀스로 만들어 재생합니다.
    /// </summary>
    private void PlaySequence(List<UIAnimAction> actions, Action onComplete)
    {
        if (rectTransform == null) rectTransform = GetComponent<RectTransform>();

        // 시퀀스 생성 (일시정지 무시 여부 적용)
        activeSequence = Sequence.Create(useUnscaledTime: useUnscaledTime);

        foreach (var anim in actions)
        {
            anim.AddToSequence(activeSequence, rectTransform, useUnscaledTime);
        }

        activeSequence.OnComplete(onComplete);
    }

    /// <summary>
    /// 재생 정책에 따라 기존 애니메이션을 처리합니다.
    /// Ignore: 실행 중이면 false 반환
    /// Restart: 실행 중이면 중지하고 true 반환
    /// </summary>
    private bool HandlePolicy()
    {
        if (activeSequence.isAlive)
        {
            switch (policy)
            {
                case PlaybackPolicy.Ignore: return false;
                case PlaybackPolicy.Restart: 
                    activeSequence.Stop(); 
                    break;
            }
        }
        return true;
    }

    /// <summary>
    /// blockInteraction 설정에 따라 UI 상호작용을 활성화/비활성화합니다.
    /// </summary>
    private void SetInteractable(bool interactable)
    {
        if (!blockInteraction || !Application.isPlaying) return;

        if(canvasGroup != null) canvasGroup.blocksRaycasts = interactable;
    }
    #endregion

    #region [ Helper Methods for InfoBox ]
    /// <summary>
    /// In 애니메이션의 총 재생 시간을 계산합니다.
    /// </summary>
    private string InDurationText => $"애니메이션 재생 시간: {CalculateDuration(inActions)} 초";
    
    /// <summary>
    /// Out 애니메이션의 총 재생 시간을 계산합니다.
    /// </summary>
    private string OutDurationText => $"애니메이션 재생 시간: {CalculateDuration(outActions)} 초";

    /// <summary>
    /// 주어진 액션 리스트의 총 재생 시간을 계산합니다.
    /// 병렬 처리(isChain=false)와 순차 처리(isChain=true)를 모두 고려합니다.
    /// </summary>
private string CalculateDuration(List<UIAnimAction> actions)
    {
        if (actions == null || actions.Count == 0) return "0";

        // PrimeTween Sequence 모델과 동일하게 계산:
        // Group(isChain=false) → chainPoint 기준으로 병렬 실행, sequenceDuration 연장
        // Chain(isChain=true)  → sequenceDuration 끝에 순차 추가, chainPoint 갱신
        float sequenceDuration = 0f;
        float chainPoint = 0f;

        foreach (var anim in actions)
        {
            if (anim == null) continue;
            if (anim.cycles < 0) return "\u221e"; // 무한 반복

            float tweenDuration = anim.startDelay + anim.duration * anim.cycles;

            if (anim.isChain)
            {
                chainPoint = sequenceDuration;
                sequenceDuration = chainPoint + tweenDuration;
            }
            else
            {
                sequenceDuration = Mathf.Max(sequenceDuration, chainPoint + tweenDuration);
            }
        }
        return sequenceDuration.ToString("F2");
    }
    #endregion

    #region [ Editor Preview ]
    /// <summary>
    /// 에디터에서 In 애니메이션을 미리 봅니다.
    /// </summary>
    [HorizontalGroup("Preview")]
    [Button(Name = "▶ Preview In"), GUIColor(0.7f, 1f, 0.7f)]
    public void EditorPreviewIn()
    {
        PreparePreview();
        PlayIn(null, true);
    }

    /// <summary>
    /// 에디터에서 Out 애니메이션을 미리 봅니다.
    /// </summary>
    [HorizontalGroup("Preview")]
    [Button(Name = "▶ Preview Out"), GUIColor(0.7f, 1f, 0.7f)]
    public void EditorPreviewOut()
    {
        PreparePreview();
        PlayOut(null, true);
    }

    /// <summary>
    /// 애니메이션 프리뷰를 중단하고 초기 상태로 돌립니다.
    /// </summary>
    [Button(Name = "■ Reset"), GUIColor(1f, 0.7f, 0.7f)]
    [PropertySpace(SpaceBefore = 10)]
    public void StopPreview()
    {
        Cleanup();
        isPreviewing = false;
        currentState = UIState.Closed;
        ApplyInitialState();
    }

    /// <summary>
    /// 프리뷰를 위한 사전 준비를 수행합니다.
    /// </summary>
    private void PreparePreview()
    {
        if (rectTransform == null) rectTransform = GetComponent<RectTransform>();
        if (!isPreviewing)
        {
            RecordInitialState();
            isPreviewing = true;
        }

        Cleanup();
    }

    /// <summary>
    /// 모든 액션의 초기 상태를 기록합니다.
    /// </summary>
    private void RecordInitialState() => IterateAllAction(anim => anim.RecordState(rectTransform));

    /// <summary>
    /// 모든 액션을 초기 상태로 되돌립니다.
    /// </summary>
    private void ApplyInitialState() => IterateAllAction(anim => anim.ResetState(rectTransform));

    /// <summary>
    /// In, Out, Loop 액션 모두에 대해 주어진 액션을 수행합니다.
    /// </summary>
    private void IterateAllAction(Action<UIAnimAction> action)
    {
        if(rectTransform == null) rectTransform = GetComponent<RectTransform>();
        inActions?.ForEach(action);
        outActions?.ForEach(action);
        loopActions?.ForEach(action);
    }

    /// <summary>
    /// UIAnimAction의 모든 서브클래스를 가져옵니다.
    /// OdinInspector의 TypeFilter에서 사용됩니다.
    /// </summary>
    private IEnumerable<Type> GetActionTypes()
    {
        return typeof(UIAnimAction).Assembly.GetTypes()
            .Where(x => !x.IsAbstract && typeof(UIAnimAction).IsAssignableFrom(x));
    }
    #endregion
}