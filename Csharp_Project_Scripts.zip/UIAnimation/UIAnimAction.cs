using System;
using UnityEngine;
using PrimeTween;
using Sirenix.OdinInspector;

[Serializable]
public abstract class UIAnimAction
{
    [HorizontalGroup("Header")]
    [BoxGroup("Header/Target", ShowLabel = false)]
    [LabelText("타겟"), Tooltip("비어있으면 마스터오브젝트의 RectTransform을 사용")]
    [HideLabel] public RectTransform customTarget;

    [BoxGroup("Header/Chain", ShowLabel = false)]
    [LabelText("연속 실행"), Tooltip("이전 애니메이션 완료 후 실행 여부")]
    public bool isChain = false;

    [BoxGroup("Settings", ShowLabel = false)]
    [HorizontalGroup("Settings/Row")]
    [LabelText("지연"), Unit(Units.Second)] public float startDelay;
    
    [HorizontalGroup("Settings/Row")]
    [LabelText("시간"), Unit(Units.Second)] public float duration = 0.3f;

    [HorizontalGroup("Settings/Row")]
    [LabelText("상대값"), Tooltip("켜면 목표값이 현재값 기준 상대값으로 적용됩니다\n• Move/Rotate/Fade: 현재값 + 설정값 (덧셈)\n• Scale: 현재값 × 설정값 (배율 곱셈)")]
    public bool useRelative = true;

    [BoxGroup("Ease", ShowLabel = false)]
    [HorizontalGroup("Ease/Row")]
    [LabelWidth(85), LabelText("커스텀 커브")] public bool useCustomCurve;
    
    [HorizontalGroup("Ease/Row")]
    [HideLabel, ShowIf("useCustomCurve")]
    public AnimationCurve customCurve = AnimationCurve.EaseInOut(0, 0, 1, 1);

    [HorizontalGroup("Ease/Row")]
    [HideLabel, HideIf("useCustomCurve")]
    public Ease ease = Ease.OutQuad;

    [FoldoutGroup("추가 설정", expanded: false)]
    [HorizontalGroup("추가 설정/Row")]
    [LabelWidth(50),LabelText("반복"), Tooltip("-1이면 무한 반복")]
    public int cycles = 1;
    
    [HorizontalGroup("추가 설정/Row")]
    [LabelWidth(75), LabelText("반복 모드")]
    public CycleMode cycleMode = CycleMode.Restart;

    /// <summary>
    /// 사용할 RectTransform을 반환합니다.
    /// customTarget이 설정되었으면 그것을, 아니면 마스터 타겟을 반환합니다.
    /// </summary>
    protected RectTransform GetTarget(RectTransform masterTarget) 
        => customTarget != null ? customTarget : masterTarget;

    /// <summary>
    /// 실제 Tween 객체를 생성합니다.
    /// 각 구현체에서 재정의하여 고유한 애니메이션 로직을 정의합니다.
    /// </summary>
    protected abstract Tween InvokeTween(RectTransform target, bool useUnscaledTime);

    /// <summary>
    /// 주어진 시퀀스에 이 애니메이션을 추가합니다.
    /// isChain에 따라 순차 실행(Chain) 또는 병렬 실행(Group)을 결정합니다.
    /// </summary>
    public virtual void AddToSequence(Sequence sequence, RectTransform masterTarget, bool useUnscaledTime)
    {
        RectTransform t = GetTarget(masterTarget);
        if (t == null) return;

        Tween tween = InvokeTween(t, useUnscaledTime);
        
        // Tween 생성 실패 시 시퀀스에 추가하지 않음
        if (!tween.isAlive) return;
        
        if (isChain) sequence.Chain(tween);
        else sequence.Group(tween);
    }

    /// <summary>
    /// 현재 상태를 스냅샷으로 저장합니다.
    /// 에디터 프리뷰 후 초기 상태로 돌아갈 때 사용됩니다.
    /// </summary>
    public abstract void RecordState(RectTransform target);
    
    /// <summary>
    /// RecordState에서 저장한 상태로 복구합니다.
    /// 에디터 프리뷰 중단 시 호출됩니다.
    /// </summary>
    public abstract void ResetState(RectTransform target);

    /// <summary>
    /// 루프 애니메이션용 Tween을 생성합니다.
    /// 별도의 시퀀스 없이 독립적으로 재생됩니다.
    /// </summary>
    public Tween GenerateTween(RectTransform masterTarget, bool useUnscaledTime)
    {
        RectTransform t = GetTarget(masterTarget);
        if (t == null) return default;
        return InvokeTween(t, useUnscaledTime);
    }
}